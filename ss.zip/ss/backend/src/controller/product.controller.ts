import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

import { errorHandler } from "../middleware/error.middleware";
import responseLib from "../lib/responseLib";
const Products = mongoose.model("products");

/**
 * @desc    Get user profile
 * @route   GET /api/auth/profile
 * @access  Protected
 */
 const getAllProducts = async (req: Request, res: Response) => {
	try {
		const page = parseInt(req.query.page as string) || 1;
		const limit = parseInt(req.query.limit as string) || 10;
		const skip = (page - 1) * limit;
		const [products, total] = await Promise.all([
			Products.find().skip(skip).limit(limit).sort({ createdAt: -1 }),
			Products.countDocuments(),
		]);

		const response = responseLib.generateApiResponse(
			false,
			{
				products,
				total,
				page,
				totalPages: Math.ceil(total / limit),
			},
			"products fetch succefully",
			undefined
		);
		return res.status(200).send(response);
	} catch (error) {
		const response = responseLib.generateApiResponse(
			true,
			null,
			"Failed to fetch products",
			error
		);
		return res.status(500).send(response);
	}
};

 const createProducts = async (req: Request, res: Response) => {
  try {
    let product_data = req.body;
		const newProduct = new Products(product_data);
		await newProduct.save();

		const response = responseLib.generateApiResponse(
			false,
			{},
			"product created succefully",
			undefined
		);
		return res.status(201).send(response);
	} catch (err) {
		const response = responseLib.generateApiResponse(
			true,
			null,
			"Failed to create product",
			error
		);
		return res.status(500).send(response);
	}
};

 const updateProducts = async (req: Request, res: Response) => {
  try {
 let { product_id, ...product_data } = req.body;
		await Product.findByIdAndUpdate(product_id, product_data, { runValidators: true });

		const response = responseLib.generateApiResponse(
			false,
			{},
			"product updated succefully",
			undefined
		);
		return res.status(201).send(response);
	} catch (err) {
		const response = responseLib.generateApiResponse(
			true,
			null,
			"Failed to update product",
			error
		);
		return res.status(500).send(response);
	}
};
 const deleteProduct = async (req: Request, res: Response) => {
	try {
		

		let product_id = req.body.product_id;
		await Product.findByIdAndDelete(product_id);
		const response = responseLib.generateApiResponse(
			false,
			{},
			"product deleted succefully",
			undefined
		);
		return res.status(201).send(response);
	} catch (err) {
		const response = responseLib.generateApiResponse(
			true,
			null,
			"Failed to delete product",
			error
		);
		return res.status(500).send(response);
	}
};


export default {
  getAllProducts,
  createProducts,
  updateProducts,
  deleteProduct
}