// @ts-nocheck
/**
 * @file_purpose  crud operation with product collection related routes
 * @author Jyoti prakash panigrahi
 * @Date_Created 19-jun-2025
 * @Date_Modified
 */

import appConfig from "../config/Index";
import {
	validate,
	createProductValidationSchema,
	updateProductValidationSchema,
	deleteProductValidationSchema,
} from "../middleware/validate.middleware";
import auth from "../middleware/auth.middleware";
import productController from "../controller/product.controller";
const setRouter = (app) => {
	const { apiVersion } = appConfig;
	app.post(apiVersion + "get-all-product", productController.getAllProducts);
	app.post(
		apiVersion + "create-product",
		validate(createProductValidationSchema),
		productController.createProducts
	);
	app.post(
		apiVersion + "update-product",
		validate(updateProductValidationSchema),
		productController.updateProducts
	);
	app.post(
		apiVersion + "delete-product",
		validate(deleteProductValidationSchema),
		productController.deleteProduct
	);
};

module.exports = {
	setRouter: setRouter,
};
