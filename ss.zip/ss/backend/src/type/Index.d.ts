import { JwtPayload } from 'jsonwebtoken';

export interface AuthUserPayload {
  id: string;
  email?: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUserPayload | JwtPayload;
    }
  }
}



import { EventEmitter } from 'events';
import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';

// Load env variables
dotenv.config();

export interface DBConfig {
  redis_url: string;
  mq_url: string;
  username: string;
  password: string;
  database: string;
}

export interface AppConfig {
  redis_url: string;
  mq_url: string;
  eventEmitter: EventEmitter;
  allowedCorsOrigin: string;
  allowedCorsMethods: string;
  allowedCorsHeaders: string;
  allowCorsCredentials: string;
  apiVersion: string;
  sessionExpTime: number;
  urlExpTime: number;
  otpLinkExpTime: number;
  db: {
    uri: string;
  };
  baseUrl: string;

}



// // Resolve and read config
// const env = process.env.NODE_ENV || 'development';
// const configPath = path.resolve(__dirname, 'dbConfig.json');

// let dbConfig: DBConfig;

// try {
//   const configFile = fs.readFileSync(configPath, 'utf-8');
//   const parsedConfig = JSON.parse(configFile);

//   dbConfig = parsedConfig[env];
//   if (!dbConfig) {
//     console.error(`Database config not set for environment: ${env}`);
//     process.exit(1);
//   }
// } catch (err: any) {
//   console.error(`Failed to load dbConfig.json: ${err.message}`);
//   process.exit(1);
// }

// // Create config
// const appConfig: AppConfig = {
//   redis_url: dbConfig.redis_url,
//   mq_url: dbConfig.mq_url,
//   eventEmitter: new EventEmitter(),
//   allowedCorsOrigin: '*',
//   allowedCorsMethods: 'GET, POST, PUT, DELETE',
//   allowedCorsHeaders: 'Authorization',
//   allowCorsCredentials: 'true',
//   apiVersion: '/api/v1',
//   sessionExpTime: 124 * 124, // example: 24 hours
//   urlExpTime: 60,
//   otpLinkExpTime: 3,
//   db: {
//     uri: `mongodb+srv://${dbConfig.username}:${dbConfig.password}@cluster0.zmo6ugy.mongodb.net/${dbConfig.database}?retryWrites=true&w=majority`,
//   },
//   baseUrl: '',
// };

// export default appConfig;
